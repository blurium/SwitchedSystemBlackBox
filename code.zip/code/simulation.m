deltatotal=zeros(1,11);
lbtotal=zeros(1,11);
ubtotal=zeros(1,11);
for t=1:10
   testub079;
   deltatotal=deltaarray+deltatotal;
   lbtotal=lbtotal+lbarray;
   ubtotal=ubtotal+ubarray;
end