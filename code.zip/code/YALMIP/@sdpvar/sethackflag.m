function X = sethackflag(X,flag)
%GETHACKFLAG Internal function to set constraint type

X.typeflag = flag;
