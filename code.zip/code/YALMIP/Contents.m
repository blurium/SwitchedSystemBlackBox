% YALMIP
% Version 30-Sep-2016
% Help on http://yalmip.github.io
